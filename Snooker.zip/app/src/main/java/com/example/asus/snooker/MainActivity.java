package com.example.asus.snooker;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    //icon authour <div>Icons made by <a href="https://www.freepik.com/" title="Freepik">Freepik</a> from <a href="https://www.flaticon.com/" 			    title="Flaticon">www.flaticon.com</a> is licensed by <a href="http://creativecommons.org/licenses/by/3.0/" 			    title="Creative Commons BY 3.0" target="_blank">CC 3.0 BY</a></div>

    public static String NAME1_KEY = "name1_key";
    public static String NAME2_KEY = "name2_key";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //find the edit texts for the players name
        final EditText name1 = (EditText) findViewById(R.id.player1_name);
        final EditText name2 = (EditText) findViewById(R.id.player2_name);

        Button start = (Button) findViewById(R.id.start); //find the start button

        start.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, GameActivity.class); //create the intent
                //put the name strings for the players name information
                intent.putExtra(NAME1_KEY, name1.getText().toString());
                intent.putExtra(NAME2_KEY, name2.getText().toString());
                startActivity(intent); //start the intent
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id==R.id.menu_help) {
            Intent intent = new Intent(MainActivity.this, InformationActivity.class);
            startActivity(intent);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
