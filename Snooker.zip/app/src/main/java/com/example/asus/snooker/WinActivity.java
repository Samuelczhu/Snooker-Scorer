package com.example.asus.snooker;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class WinActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_win);

        Intent intent = getIntent(); //get the intent

        //find the views
        TextView winner_name = (TextView) findViewById(R.id.winner_name);
        TextView winner_score = (TextView) findViewById(R.id.winner_score);

        //set the texts
        winner_name.setText(intent.getStringExtra(GameActivity.WINNER_KEY));
        winner_score.setText(intent.getStringExtra(GameActivity.SCORE_KEY));
    }
}
