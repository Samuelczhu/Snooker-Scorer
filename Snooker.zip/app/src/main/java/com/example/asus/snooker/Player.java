package com.example.asus.snooker;

/**
 * This Player class holds the information for a player, and it is used to update the UI
 * @author samueczhu
 * @version 2019/2/17
 */
public class Player {

    private String name; //the name of the player
    private int totalScore; //the total score
    //hold the value for the balls that was in
    private int red, yellow, green, brown, blue, pink, black;

    //static field for the ball code
    public static int RED = 0;
    public static int YELLOW = 1;
    public static int GREEN = 2;
    public static int BROWN = 3;
    public static int BLUE = 4;
    public static int PINK = 5;
    public static int BLACK = 6;

    //static fields for the ball values
    public static int RED_SCORE = 1;
    public static int YELLOW_SCORE = 2;
    public static int GREEN_SCORE = 3;
    public static int BROWN_SCORE = 4;
    public static int BLUE_SCORE = 5;
    public static int PINK_SCORE = 6;
    public static int BLACK_SCORE = 7;

    //operation code used in the listener
    public static int ADD = 0;
    public static int MINUS = 1;

    /**
     * Constructor for player, set all things to default
     * @param name the name of the player
     */
    public Player(String name) {
        this.name = name;
        this.totalScore = 0;
        red=0; yellow=0; green=0; brown=0; blue = 0; pink=0; black=0;
    }

    /**
     * set the total score directly, should be a non-negative integer
     * @param score the score to set
     */
    public void setTotalScore(int score) {
        if (score>=0)
            this.totalScore=score;
    }

    /**
     * add the count of the corresponding ball and points
     * @param ball the int represent the ball's color
     */
    public void addBall(int ball) {
        switch (ball) {
            case 0:
                red++;
                totalScore += RED_SCORE;
                break;
            case 1:
                yellow++;
                totalScore += YELLOW_SCORE;
                break;
            case 2:
                green++;
                totalScore += GREEN_SCORE;
                break;
            case 3:
                brown++;
                totalScore += BROWN_SCORE;
                break;
            case 4:
                blue++;
                totalScore += BLUE_SCORE;
                break;
            case 5:
                pink++;
                totalScore += PINK_SCORE;
                break;
            case 6:
                black++;
                totalScore += BLACK_SCORE;
                break;
        }
    }

    /**
     * minus the count of corresponding ball and points
     * @param ball
     */
    public void minusBall(int ball) {
        switch (ball) {
            case 0:
                if (red>0) {
                    red--;
                    totalScore -= RED_SCORE;
                }
                break;
            case 1:
                if (yellow>0) {
                    yellow--;
                    totalScore -= YELLOW_SCORE;
                }
                break;
            case 2:
                if (green>0) {
                    green--;
                    totalScore -= GREEN_SCORE;
                }
                break;
            case 3:
                if (brown>0) {
                    brown--;
                    totalScore -= BROWN_SCORE;
                }
                break;
            case 4:
                if (blue>0) {
                    blue--;
                    totalScore -= BLUE_SCORE;
                }
                break;
            case 5:
                if (pink>0) {
                    pink--;
                    totalScore -= PINK_SCORE;
                }
                break;
            case 6:
                if (black>0) {
                    black--;
                    totalScore -= BLACK_SCORE;
                }
                break;
        }
        if (totalScore<0) { //make sure negative point wont happen
            totalScore=0;
        }
    }



    //getters
    public String getName() {
        return name;
    }

    public int getTotalScore() {
        return totalScore;
    }

    public int getRed() {
        return red;
    }

    public int getYellow() {
        return yellow;
    }

    public int getGreen() {
        return green;
    }

    public int getBrown() {
        return brown;
    }

    public int getBlue() {
        return blue;
    }

    public int getPink() {
        return pink;
    }

    public int getBlack() {
        return black;
    }
}
