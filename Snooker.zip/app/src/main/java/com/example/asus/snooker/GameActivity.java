package com.example.asus.snooker;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class GameActivity extends AppCompatActivity {

    //string keys for other activity to use
    public static String SCORE_KEY = "score_key";
    public static String WINNER_KEY = "winner_key";

    //two players
    private Player player1;
    private Player player2;

    //Views for player1
    private TextView name1_text; //name for player 1
    private EditText totalScore1_editText; //total score for player 1
    //buttons for adding points for player 1
    private Button redAdd1, yellowAdd1, greenAdd1, brownAdd1, blueAdd1, pinkAdd1, blackAdd1;
    //buttons for minus points for player 1
    private Button redMinus1, yellowMinus1, greenMinus1, brownMinus1, blueMinus1, pinkMinus1, blackMinus1;
    //counts textViews for color ball
    private TextView redCount1, yellowCount1, greenCount1, brownCount1, blueCount1, pinkCount1, blackCount1;

    //Views for player 2
    private TextView name2_text; //name for player 2
    private EditText totalScore2_editText; //total score for player 2
    //buttons for adding points for player 2
    private Button redAdd2, yellowAdd2, greenAdd2, brownAdd2, blueAdd2, pinkAdd2, blackAdd2;
    //buttons for minus points for player 2
    private Button redMinus2, yellowMinus2, greenMinus2, brownMinus2, blueMinus2, pinkMinus2, blackMinus2;
    //counts textViews for color ball
    private TextView redCount2, yellowCount2, greenCount2, brownCount2, blueCount2, pinkCount2, blackCount2;

    //Buttons to end game
    private Button end;

    /**
     * AddMinusListener is used for the listener for buttons
     */
    private class AddMinusListener implements View.OnClickListener {

        private int player; //1 for player 1, 2 for player 2
        private int ball; //ball to add, should be correspond to the color int declared in Player class
        private int operation; //0 for add, 1 for minus

        private AddMinusListener(int player, int ball, int operation) {
            this.player = player;
            this.ball = ball;
            this.operation = operation;
        }

        /**
         * Handle click events based on the ball and player
         * @param view the view that passed in automatically
         */
        @Override
        public void onClick(View view) {
            if (player==1) { //player1
                if (operation==0) { //add
                    player1.addBall(ball);
                } else if (operation==1) { //minus
                    player1.minusBall(ball);
                }
                updateUI1(); //update the player 1 UI
            } else if (player==2) { //player 2
                if (operation==0) { //add
                    player2.addBall(ball);
                } else if (operation==1) { //minus
                    player2.minusBall(ball);
                }
                updateUI2();
            }
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game);

        //find the end game button
        end = (Button) findViewById(R.id.end_game);

        //find the views with corresponding ids for player1
        name1_text = (TextView) findViewById(R.id.player1_name);
        totalScore1_editText = (EditText) findViewById(R.id.player1_score);
        redAdd1 = (Button) findViewById(R.id.red_ball_add1);
        redMinus1 = (Button) findViewById(R.id.red_ball_minus1) ;
        yellowAdd1 = (Button) findViewById(R.id.yellow_ball_add1);
        yellowMinus1 = (Button) findViewById(R.id.yellow_ball_minus1);
        greenAdd1 = (Button) findViewById(R.id.green_ball_add1);
        greenMinus1 = (Button) findViewById(R.id.green_ball_minus1);
        brownAdd1 = (Button) findViewById(R.id.brown_ball_add1);
        brownMinus1 = (Button) findViewById(R.id.brown_ball_minus1);
        blueAdd1 = (Button) findViewById(R.id.blue_ball_add1);
        blueMinus1 = (Button) findViewById(R.id.blue_ball_minus1);
        pinkAdd1 = (Button) findViewById(R.id.pink_ball_add1);
        pinkMinus1 = (Button) findViewById(R.id.pink_ball_minus1);
        blackAdd1 = (Button) findViewById(R.id.black_ball_add1);
        blackMinus1 = (Button) findViewById(R.id.black_ball_minus1);
        redCount1 = (TextView) findViewById(R.id.red_ball_count1);
        yellowCount1 = (TextView) findViewById(R.id.yellow_ball_count1);
        greenCount1 = (TextView) findViewById(R.id.green_ball_count1);
        brownCount1 = (TextView) findViewById(R.id.brown_ball_count1);
        blueCount1 = (TextView) findViewById(R.id.blue_ball_count1);
        pinkCount1 = (TextView) findViewById(R.id.pink_ball_count1);
        blackCount1 = (TextView) findViewById(R.id.black_ball_count1);


        //find the views with corresponding ids for player2
        name2_text = (TextView) findViewById(R.id.player2_name);
        totalScore2_editText = (EditText) findViewById(R.id.player2_score);
        redAdd2 = (Button) findViewById(R.id.red_ball_add2);
        redMinus2 = (Button) findViewById(R.id.red_ball_minus2) ;
        yellowAdd2 = (Button) findViewById(R.id.yellow_ball_add2);
        yellowMinus2 = (Button) findViewById(R.id.yellow_ball_minus2);
        greenAdd2 = (Button) findViewById(R.id.green_ball_add2);
        greenMinus2 = (Button) findViewById(R.id.green_ball_minus2);
        brownAdd2 = (Button) findViewById(R.id.brown_ball_add2);
        brownMinus2 = (Button) findViewById(R.id.brown_ball_minus2);
        blueAdd2 = (Button) findViewById(R.id.blue_ball_add2);
        blueMinus2 = (Button) findViewById(R.id.blue_ball_minus2);
        pinkAdd2 = (Button) findViewById(R.id.pink_ball_add2);
        pinkMinus2 = (Button) findViewById(R.id.pink_ball_minus2);
        blackAdd2 = (Button) findViewById(R.id.black_ball_add2);
        blackMinus2 = (Button) findViewById(R.id.black_ball_minus2);
        redCount2 = (TextView) findViewById(R.id.red_ball_count2);
        yellowCount2 = (TextView) findViewById(R.id.yellow_ball_count2);
        greenCount2 = (TextView) findViewById(R.id.green_ball_count2);
        brownCount2 = (TextView) findViewById(R.id.brown_ball_count2);
        blueCount2 = (TextView) findViewById(R.id.blue_ball_count2);
        pinkCount2 = (TextView) findViewById(R.id.pink_ball_count2);
        blackCount2 = (TextView) findViewById(R.id.black_ball_count2);

        Intent intent = getIntent(); //get the intent for the player names

        //create two players
        player1 = new Player(intent.getStringExtra(MainActivity.NAME1_KEY));
        player2 = new Player(intent.getStringExtra(MainActivity.NAME2_KEY));

        totalScore1_editText.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                //tell the user it is not recommended to set score directly
                Toast.makeText(GameActivity.this, R.string.not_score,Toast.LENGTH_SHORT).show();
                if (actionId == EditorInfo.IME_ACTION_DONE || (event.getKeyCode() == KeyEvent.KEYCODE_ENTER && event.getAction() == KeyEvent.ACTION_DOWN)) {
                    String value = totalScore1_editText.getText().toString();
                    if (value != null && !value.equals("")) { //prevent empty input from user
                        player1.setTotalScore(Integer.valueOf(value));
                    }
                    updateUI1();
                    //hide the keyboard when done
                    InputMethodManager imm = (InputMethodManager)v.getContext().getSystemService(Context.INPUT_METHOD_SERVICE);
                    imm.hideSoftInputFromWindow(v.getWindowToken(), 0);
                    totalScore1_editText.clearFocus();
                    return true;
                }
                return false;
            }
        });
        totalScore2_editText.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                Toast.makeText(GameActivity.this, R.string.not_score,Toast.LENGTH_SHORT).show();
                if (actionId == EditorInfo.IME_ACTION_DONE || (event.getKeyCode() == KeyEvent.KEYCODE_ENTER && event.getAction() == KeyEvent.ACTION_DOWN)) {
                    String value = totalScore2_editText.getText().toString();
                    if (value != null && !value.equals("")) { //prevent empty input from user
                        player2.setTotalScore(Integer.valueOf(value));
                    }
                    updateUI2();
                    //hide the keyboard when done
                    InputMethodManager imm = (InputMethodManager)v.getContext().getSystemService(Context.INPUT_METHOD_SERVICE);
                    imm.hideSoftInputFromWindow(v.getWindowToken(), 0);
                    totalScore2_editText.clearFocus();
                    return true;
                }
                return false;
            }
        });

        //setting the onclick listener for buttons for player 1
        redAdd1.setOnClickListener(new AddMinusListener(1,Player.RED,Player.ADD));
        redMinus1.setOnClickListener(new AddMinusListener(1,Player.RED,Player.MINUS));
        yellowAdd1.setOnClickListener(new AddMinusListener(1,Player.YELLOW,Player.ADD));
        yellowMinus1.setOnClickListener(new AddMinusListener(1, Player.YELLOW, Player.MINUS));
        greenAdd1.setOnClickListener(new AddMinusListener(1, Player.GREEN,Player.ADD));
        greenMinus1.setOnClickListener(new AddMinusListener(1, Player.GREEN, Player.MINUS));
        brownAdd1.setOnClickListener(new AddMinusListener(1, Player.BROWN, Player.ADD));
        brownMinus1.setOnClickListener(new AddMinusListener(1,Player.BROWN,Player.MINUS));
        blueAdd1.setOnClickListener(new AddMinusListener(1, Player.BLUE, Player.ADD));
        blueMinus1.setOnClickListener(new AddMinusListener(1, Player.BLUE,Player.MINUS));
        pinkAdd1.setOnClickListener(new AddMinusListener(1, Player.PINK, Player.ADD));
        pinkMinus1.setOnClickListener(new AddMinusListener(1, Player.PINK, Player.MINUS));
        blackAdd1.setOnClickListener(new AddMinusListener(1, Player.BLACK, Player.ADD));
        blackMinus1.setOnClickListener(new AddMinusListener(1, Player.BLACK, Player.MINUS));

        //setting the onclick listener for buttons for player 2
        redAdd2.setOnClickListener(new AddMinusListener(2,Player.RED,Player.ADD));
        redMinus2.setOnClickListener(new AddMinusListener(2,Player.RED,Player.MINUS));
        yellowAdd2.setOnClickListener(new AddMinusListener(2,Player.YELLOW,Player.ADD));
        yellowMinus2.setOnClickListener(new AddMinusListener(2, Player.YELLOW, Player.MINUS));
        greenAdd2.setOnClickListener(new AddMinusListener(2, Player.GREEN,Player.ADD));
        greenMinus2.setOnClickListener(new AddMinusListener(2, Player.GREEN, Player.MINUS));
        brownAdd2.setOnClickListener(new AddMinusListener(2, Player.BROWN, Player.ADD));
        brownMinus2.setOnClickListener(new AddMinusListener(2,Player.BROWN,Player.MINUS));
        blueAdd2.setOnClickListener(new AddMinusListener(2, Player.BLUE, Player.ADD));
        blueMinus2.setOnClickListener(new AddMinusListener(2, Player.BLUE,Player.MINUS));
        pinkAdd2.setOnClickListener(new AddMinusListener(2, Player.PINK, Player.ADD));
        pinkMinus2.setOnClickListener(new AddMinusListener(2, Player.PINK, Player.MINUS));
        blackAdd2.setOnClickListener(new AddMinusListener(2, Player.BLACK, Player.ADD));
        blackMinus2.setOnClickListener(new AddMinusListener(2, Player.BLACK, Player.MINUS));

        //set the end game listener
        end.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //compare two players score
                if (player1.getTotalScore()==player2.getTotalScore()) { //tie
                    Intent tieIntent = new Intent(GameActivity.this, TiedActivity.class);
                    tieIntent.putExtra(SCORE_KEY, String.valueOf(player1.getTotalScore()));
                    startActivity(tieIntent);
                } else { //not tied
                    Intent winnerIntent = new Intent(GameActivity.this, WinActivity.class);
                    //get the winner
                    Player winner = (player1.getTotalScore()>player2.getTotalScore()) ? (player1):(player2);
                    winnerIntent.putExtra(SCORE_KEY, String.valueOf(winner.getTotalScore()));
                    winnerIntent.putExtra(WINNER_KEY, winner.getName());
                    startActivity(winnerIntent);
                }
            }
        });

        //update the UI
        updateUI1();
        updateUI2();
    }

    /**
     * update the UI for player 1
     */
    public void updateUI1() {
        name1_text.setText(player1.getName());
        totalScore1_editText.setText(String.valueOf(player1.getTotalScore()));
        redCount1.setText(String.valueOf(player1.getRed()));
        yellowCount1.setText(String.valueOf(player1.getYellow()));
        greenCount1.setText(String.valueOf(player1.getGreen()));
        brownCount1.setText(String.valueOf(player1.getBrown()));
        blueCount1.setText(String.valueOf(player1.getBlue()));
        pinkCount1.setText(String.valueOf(player1.getPink()));
        blackCount1.setText(String.valueOf(player1.getBlack()));
        showWarning();
    }

    /**
     * update the UI for player 2
     */
    public void updateUI2() {
        name2_text.setText(player2.getName());
        totalScore2_editText.setText(String.valueOf(player2.getTotalScore()));
        redCount2.setText(String.valueOf(player2.getRed()));
        yellowCount2.setText(String.valueOf(player2.getYellow()));
        greenCount2.setText(String.valueOf(player2.getGreen()));
        brownCount2.setText(String.valueOf(player2.getBrown()));
        blueCount2.setText(String.valueOf(player2.getBlue()));
        pinkCount2.setText(String.valueOf(player2.getPink()));
        blackCount2.setText(String.valueOf(player2.getBlack()));
        showWarning();
    }

    private void showWarning() {
        if (player1.getRed()>15 || player2.getRed()>15) { //impossible to happen
            Toast.makeText(GameActivity.this,R.string.max_red,Toast.LENGTH_SHORT).show();
        }
        if (player1.getTotalScore()>147 || player2.getTotalScore()>147) {
            Toast.makeText(GameActivity.this,R.string.max_point,Toast.LENGTH_SHORT).show();
        }
    }

    //create the menu and handle click

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id==R.id.menu_help) {
            Intent intent = new Intent(GameActivity.this, InformationActivity.class);
            startActivity(intent);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
