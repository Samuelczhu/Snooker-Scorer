package com.example.asus.snooker;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class TiedActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tied);

        Intent intent = getIntent(); //get the intent

        //find the id of the score
        TextView score = (TextView) findViewById(R.id.winner_score);
        String scoreStr = intent.getStringExtra(GameActivity.SCORE_KEY);
        score.setText((scoreStr==null || scoreStr.equals("")) ? ("0"):(scoreStr)); //set the text
    }
}
